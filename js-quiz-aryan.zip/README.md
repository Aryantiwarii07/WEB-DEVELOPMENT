# JavaScript Quiz Game
Console-based quiz game created by **Aryan Tiwari**.

## How to Run
1. Open Chrome
2. Press Ctrl + Shift + J to open console
3. Paste code from quiz.js
4. Press Enter

## Features
- Uses arrays, loops, functions
- Input with prompt()
- Feedback with alert()
- Score tracking
